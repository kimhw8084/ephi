# S09 browser blocker — candidate-bound, no source modified

The exact candidate's real browser run could not produce the required explicit
retained-snapshot-expired / Refresh guidance.

Evidence:

- `src/ephi/ui/provider.py:179` starts every Base `DataSource` query with a new
  `list_attention(...)` call. The retained cursor continuation at lines
  196–203 is only internal to that one query call; the Base table's later page
  request starts a new query and therefore a new retained snapshot.
- The exact pinned Base `DataSourceTable` wrapper forwards the fetch callback
  (`nicegui_base/integrations/nicegui_analysis.py:84`) but the EPHI page does
  not provide an `on_error` callback; the page only supplies the generic
  `error_message` at `src/ephi/ui/app.py:283`.
- The exact pinned Base `ServerDataTable` renders retained rows as generic
  `Stale data · N records` on error (`nicegui_data_table.py:1780–1788`) and
  only invokes an explicit error callback when one is supplied
  (`nicegui_data_table.py:1727–1729`, `1843–1848`).

During the browser run, security revision 1 was retained, the explicit
development identity binding rotated to revision 2, and the isolated page was
advanced to page 2. The page remained a normal `55 records / Page 2 of 2`
view with no `Attention snapshot expired` guidance. A subsequent Refresh did
create a new revision-2 snapshot and returned page 2. This proves the service
security-revision semantics are present in the reused R4 evidence, but the
required browser expiry/reconciliation surface is not bound in this candidate.

This is reported as a separate FIX boundary. No source/config repair was made.
